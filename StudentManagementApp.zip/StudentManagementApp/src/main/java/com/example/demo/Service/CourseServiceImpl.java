package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repositry.CourseRepository;
import com.example.demo.entity.Course;
import com.example.demo.error.StudentNotFoundException;
@Service
public class CourseServiceImpl implements CourseService{
	@Autowired
	private CourseRepository courseRepository;

	@Override
	public Course saveCourse(Course course) {
		// TODO Auto-generated method stub
		return courseRepository.save(course);
	}

	@Override
	public List<Course> fetchcourList() {
		// TODO Auto-generated method stub
		return courseRepository.findAll();
	}

	@Override
	public Course fetchCourseById(Long did) throws StudentNotFoundException {
			// TODO Auto-generated method stub
	Optional<Course> course=courseRepository.findById(did);
			
			if(!course.isPresent()) {
				throw new StudentNotFoundException("course not available");
			}
			
			else return course.get();

		
		}
	

	@Override
	public Course fetchCourseByName(String courseName) {
		// TODO Auto-generated method stub
		return courseRepository.findByCourseName(courseName);
	}
	

}
