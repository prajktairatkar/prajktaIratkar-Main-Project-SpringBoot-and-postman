package com.example.demo.Service;

import java.util.List;

import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;

public interface StudentService {

	Student saveStudent(Student student);

	List<Student> fetchStudList();

	Student fetchStudentById(Long did) throws StudentNotFoundException;

	Student updateStudent(Long did, Student student);

	Student fetchStudentByName(String studentName);

	//Student fetchStudentByEmail(String studentEmail);

	Student fetchStudentByEmail(String studentEmail);

}
