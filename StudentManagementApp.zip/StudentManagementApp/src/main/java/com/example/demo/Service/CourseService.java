package com.example.demo.Service;

import java.util.List;

import com.example.demo.entity.Course;
import com.example.demo.entity.Student;
import com.example.demo.error.StudentNotFoundException;

public interface CourseService {

	Course saveCourse(Course course);

	List<Course> fetchcourList();

	Course fetchCourseById(Long did) throws StudentNotFoundException;

	Course fetchCourseByName(String studentName);

}
